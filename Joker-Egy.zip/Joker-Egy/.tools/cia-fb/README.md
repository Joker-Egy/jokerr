# cia-fb
this is tool to facebook report
using chaldrin vuln to report 
# install

git clone https://github.com/alialialiali111/cia-fb

pip install mechanize

cd cia-fb

python2 CIA.py

# usage 
[+] coded by sofi
[+] my facebook : https://www.facebook.com/ahmed.ffrr112

Usage: CIA.py [options]

Options:
  -h, --help            show this help message and exit
  -t TARGET, --target=TARGET
                        target facebook account url
  -e EMAIL, --email=EMAIL
                        your email address
  -p PICTRUE, --pictrue=PICTRUE
                        target facebook account pictrue url
  -r RAOUND, --raound=RAOUND
                        raounds to report default:20
  -m MSG, --msg=MSG     msg to send to facebook
  -n NAME, --name=NAME  target account name
  
 
 python CIA.py -t <target_fb_url> -e <your_email> -p <target_fb_pictrue> -r <raound_to_report> -m <msg_to_facebook> -n <target_account_name>
  
