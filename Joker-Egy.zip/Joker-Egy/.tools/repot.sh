#  repot Facebook

# colors
R='\033[1;31m'                                             G='\033[1;32m'
Y='\033[1;33m'                                             C='\033[1;36m'
W='\033[1;37m'
C='\033[1;36m'
clear
echo -e "$Y"
figlet -f mono12 Repot
echo -e "$C Welcome To Tool Repot Account Facebook$Y"
echo -e "$R"
figlet -f mono12 "= 1"
read -p '1~Enter Url Account    ~: ' ta
echo -e "$G"
figlet -f mono12 "= 2"
read -p '2~Enter Email Account  ~: ' email
echo -e "$R"
figlet -f mono12 "= 3"
read -p '3~Enter PICTRUE Account~: ' photo
echo -e "$G"
figlet -f mono12 "= 4"
read -p '4~Enter Number Report  ~: ' number
echo -e "$R"
figlet -f mono12 "= 5"
read -p '5~Enter MSG Account    ~: ' msg
echo -e "$G"
figlet -f mono12 "= 6"
read -p '6~Enter Name Account   ~: ' name


clear
toilet -f mono12 -F gay ".Now"
sleep 0.5
toilet -f mono12 -F gay "Repot"
sleep 0.3
python2 cia-fb/CIA.py -t "$ta" -e $email -p "photo" -r $number -m "msg" -n "$name"

clear
echo -e "$C"
figlet -f mono12 Done.
echo -e "$G"
read -p "       Enter BaCk..^_+"
cd
cd Joker-Egy
python joker.py
