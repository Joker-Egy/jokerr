#!/bin/bash

#	colors
r='\033[1;31m'
g='\033[1;32m'
y='\033[1;33m'

echo -e "$y		About ^_^"
echo -e "$g This Tool Create Payload Android and Windows and check port Successful or erorr and install app Port Forworde .."
echo -e "$r This Tool by Mohamed Hanfy"
echo -e "$y============================================"
echo -e "$g Thanks All subscribed my channel "
echo -e "$y Thanks  "

read -p "Enter BaCk ...."
python joker.py
